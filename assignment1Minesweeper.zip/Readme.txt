Team members:
Bryan Lam
Kevin Tra Hua
Shad Malabad

We all used intelliJ

Bryan - Took me the course of 5 days with some problems with the row and col and Major problems with taking in input file and output file.
	Besides all that I had a relatively moderate deficulty.

Kevin - To complete the individual portion of the assignment it took me around 3 hours to complete the implementation with comments. To create the JUnit tests it also took
around and hour to complete. Finally, another 30 mins to go back and make sure the code follows the Naming and Style Guideline
For my individual solution, I don't believe it has any shortcomings, it follows the behavior that is expected from reading multiline input from the console and outputting
the solution in a text file. 

Shad -Between completing my individual solution and the input generator, I have roughly 10-15 hours invested. I believe my output is as intended.  