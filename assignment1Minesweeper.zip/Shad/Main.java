/*
 * TCSS 360 A
 * Assignment 1 Individual Solution
 * Winter 2022
 */

package com.company;

import java.util.Scanner;

/**
 * From the provided minefield(s), this program generates hints for the
 * location of the mines in the minefield like the minesweeper game.
 *
 * @author Shad Malabad
 * @version 18 January 2022
 */
public class Main {
    public static void main(final String[] theArgs) {

        Scanner scan = new Scanner(System.in);
        char[][] matrix = new char[0][];

        int columns = 0;
        int rows = 0;
        int row = 0;
        int x = 1;

        if (scan.hasNextLine()) {
            do {
                String input = scan.nextLine();
                // scan the first line
                if (input.matches("0 0")) {
                    System.out.println();
                } else if (!input.matches(".*\\d.*")) {
                    for (int col = 0; col < columns; col++) {
                        matrix[row][col] = input.charAt(col);
                    }
                    row++;

                    if (row == rows) {
                        String[][] finalMatrix = mineHints(matrix);
                        System.out.print(toString(finalMatrix));
                    }
                } else {
                    String delims = "[ ]+";
                    String[] tokens = input.split(delims);
                    rows = Integer.parseInt(tokens[0]);
                    row = 0;
                    columns = Integer.parseInt(tokens[1]);
                    matrix = new char[rows][columns];

                    System.out.println("\nField #" + x++ + ":");
                }
            } while (scan.hasNextLine());
        }
    }

    /**
     * Takes in the 2D character array and produces a string a 2D
     * string array that will be the hints for the given minefield.
     *
     * @param theMatrix the input 2D character array
     * @return finalMatrix the output 2D String Array
     */
    public static String[][] mineHints(final char[][] theMatrix) {
        int mineCount, postCol, preCol, postRow, preRow;
        int rows = theMatrix.length;
        int columns = theMatrix[0].length;
        String[][] finalMatrix = new String[rows][columns];

        for (int row = 0; row < rows; row++) {
            for (int column = 0; column < columns; column++) {
                if (theMatrix[row][column] == '*') {
                    finalMatrix[row][column] = "*";
                } else {
                    mineCount = 0;
                    postCol = column + 1;
                    preCol = column - 1;
                    postRow = row + 1;
                    preRow = row - 1;

                    if (preCol >= 0 && theMatrix[row][preCol] == '*') {
                        mineCount++;
                    }
                    if (postCol < columns && theMatrix[row][postCol] == '*') {
                        mineCount++;
                    }
                    if (preRow >= 0 && theMatrix[preRow][column] == '*') {
                        mineCount++;
                    }
                    if (postRow < rows && theMatrix[postRow][column] == '*') {
                        mineCount++;
                    }
                    if (preRow >= 0 && preCol >= 0 && theMatrix[preRow][preCol] == '*') {
                        mineCount++;
                    }
                    if (preRow >= 0 && postCol < columns && theMatrix[preRow][postCol] == '*') {
                        mineCount++;
                    }
                    if (postRow < rows && preCol >= 0 && theMatrix[postRow][preCol] == '*') {
                        mineCount++;
                    }
                    if (postRow < rows && postCol < columns && theMatrix[postRow][postCol] == '*') {
                        mineCount++;
                    }
                    finalMatrix[row][column] = String.valueOf(mineCount);
                }
            }
        }
        return finalMatrix;
    }

    /**
     * Takes theMatrix in and builds a string which is then returned
     *
     * @param theMatrix the input as a result of the minefield(s)
     * @return sb.toString the string that was built from param
     */
    public static String toString(String[][]theMatrix){
        StringBuilder sb = new StringBuilder();

        for (String[] matrix : theMatrix) {
            for (int j = 0; j < theMatrix[0].length; j++) {
                sb.append(matrix[j]);
            }
            sb.append("\n");
        }
        return sb.toString();
    }

}
