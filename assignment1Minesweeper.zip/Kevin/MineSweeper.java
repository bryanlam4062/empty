import java.util.*;
import java.io.*;

/**
 * TCSS 360
 * Professor Capaul
 * Minesweeper.java
 * Takes in a specific format of input of a minesweeper board with no hints and returns a file with the hints generated
 * @Author Kevin Hua
 * @version January 17th, 2022
 */

public class MineSweeper {
    private static int myRow;
    private static int myColumn;

    public static void main(String[] args) throws IOException {
        LinkedList<String> inputs = readFile(new Scanner(System.in));
        FileWriter outputFile = new FileWriter("minesweeper_output.txt");
        int fieldCount = 1;

        while (!inputs.isEmpty()) {
            String[] dimensions = inputs.removeFirst().trim().split("\\s");
            myRow = Integer.parseInt(dimensions[0]);
            myColumn = Integer.parseInt(dimensions[1]);

           outputFile.write("Field #" + fieldCount + ":" + "\n");

            char[][] mineField = new char[myRow][myColumn];

            for (int i = 0; i < myRow; i++) {
                char[] line = inputs.removeFirst().toCharArray();
                for (int j = 0; j < line.length; j++) {
                    mineField[i][j] = line[j];
                }
            }

            mineField = generateHints(mineField);

            for (int i = 0; i < myRow; i++) {
                for (int j = 0; j < myColumn; j++) {
                    outputFile.write(mineField[i][j]);
                }
                outputFile.write("\n");
            }
            outputFile.write("\n");
            fieldCount++;
        }

        outputFile.close();
    }

    /**
     * Takes the multiline input from the console and returns a list of each line to work with
     * @param theInput Scanner for System.in
     * @return a LinkedList of Strings where each index represents a line of the input
     */
    public static LinkedList<String> readFile(final Scanner theInput) {
        String line;
        LinkedList<String> inputs = new LinkedList<>();

        while (theInput.hasNextLine()) {
            line = theInput.nextLine();
            if (line.equals("0 0")) {
                break;
            }
            inputs.add(line);
        }

        return inputs;
    }

    /**
     * Takes the unsolved minefield and returns the minefield with the hints generated
     * @param theMinefield is the unsolved minefield with no hints
     * @return 2D array of chars that represent the minefield with hints
     */
    public static char[][] generateHints(final char[][] theMinefield) {
        char[][] returnMinefield = theMinefield;
        int count;
        for (int i = 0; i < myRow; i++) {
            for (int j = 0; j < myColumn; j++) {
                count = 0;
                if (theMinefield[i][j] == '.') {
                    //Top Left
                    if (checkInBoard(i - 1, j - 1)) {
                        if (theMinefield[i - 1][j - 1] == '*') {
                            count++;
                        }
                    }

                    //Top
                    if (checkInBoard(i - 1, j)) {
                        if (theMinefield[i - 1][j] == '*') {
                            count++;
                        }
                    }

                    //Top Right
                    if (checkInBoard(i - 1, j + 1)) {
                        if (theMinefield[i - 1][j + 1] == '*') {
                            count++;
                        }
                    }

                    //Left
                    if (checkInBoard(i, j - 1)) {
                        if (theMinefield[i][j - 1] == '*') {
                            count++;
                        }
                    }

                    //Right
                    if (checkInBoard(i, j + 1)) {
                        if (theMinefield[i][j + 1] == '*') {
                            count++;
                        }
                    }

                    //Bottom Left
                    if (checkInBoard(i + 1, j - 1)) {
                        if (theMinefield[i + 1][j - 1] == '*') {
                            count++;
                        }
                    }

                    //Bottom
                    if (checkInBoard(i + 1, j)) {
                        if (theMinefield[i + 1][j] == '*') {
                            count++;
                        }
                    }

                    //Bottom Right
                    if (checkInBoard(i + 1, j + 1)) {
                        if (theMinefield[i + 1][j + 1] == '*') {
                            count++;
                        }
                    }

                    returnMinefield[i][j] = (char) (count + '0');
                }
            }
        }

        return returnMinefield;
    }

    /**
     * Checks if the specified index is inside the minefield board or not
     * @param theRow - row index
     * @param theColumn - column index
     * @return True if the inputted index is in the board, False otherwise
     */
    public static boolean checkInBoard(final int theRow, final int theColumn) {
        return (theRow >= 0) && (theColumn >= 0) && (theRow < myRow) && (theColumn < myColumn);
    }
}
