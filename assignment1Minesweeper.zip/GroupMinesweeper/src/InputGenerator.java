package com.company;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

public class InputGenerator {

    public static void main(String[] args) throws FileNotFoundException {
        int rows, columns, minePercentage;
        Random rand = new Random();
        Scanner input = new Scanner(System.in);

        PrintWriter output = new PrintWriter("minesweeper_input.txt");
        rows = rand.nextInt(100);
        columns = rand.nextInt(100);

        System.out.println("How many cases would you like?: ");
        int test = input.nextInt();

        while (test != 0) {
            minePercentage = rand.nextInt(100);

            System.out.println(rows + " " + columns);
            output.println(rows + " " + columns);

            for (int currRow = 0; currRow < rows; currRow++) {
                for (int currCol = 0; currCol < columns; currCol++) {
                    if (rand.nextInt(100) < minePercentage) {
                        System.out.print('*');
                        output.print('*');
                    } else {
                        System.out.print('.');
                        output.print('.');
                    }
                }
                System.out.println();
                output.println();
            }
            rows = rand.nextInt(100);
            columns = rand.nextInt(100);
            test -= 1;
        }
        output.println("0 0");
        output.close();
        input.close();
    }


}
