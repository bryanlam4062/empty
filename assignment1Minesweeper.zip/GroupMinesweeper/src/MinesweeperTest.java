import org.junit.jupiter.api.Test;
import java.io.File;

class MinesweeperTest {
    @Test
    public void test1Mine() {
        File input = new File("src/Test Files/1MineOutput.txt");
        File solution = new File("src/Test Files/1MineOutputSolution.txt");

        junitx.framework.FileAssert.assertEquals(solution, input);
    }

    @Test
    public void testCanvasInput() {
        File input = new File("src/Test Files/minesweeper_output.txt");
        File solution = new File("src/Test Files/minesweeper_output _solution.txt");

        junitx.framework.FileAssert.assertEquals(solution, input);
    }

    @Test
    public void testOfficialInputFile() {
        File input = new File("src/Test Files/official_minesweeper_output.txt");
        File solution = new File("src/Test Files/official_minesweeper_output_solution.txt");

        junitx.framework.FileAssert.assertEquals(solution, input);
    }
}