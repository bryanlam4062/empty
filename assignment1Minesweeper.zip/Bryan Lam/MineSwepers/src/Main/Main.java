package Main;

import MineSweeperSystem.MineSweeperSystem;

import java.io.File;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Main.java
 *
 * main class that runs program to create minesweeper board.
 *
 * @Author Bryan Lam
 * @version winter 2022

 * class main
 */
public class Main {
    /**
     * Main class to start the program,
     * takes file input with board pre-created
     * and change it into an endgame board.
     * @param args args
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String fileLocation = "C:\\Users\\Guilty\\Documents\\UWT 2018 -" +
                " present\\UWT 2021 - 2022\\Winter\\TCSS 360\\Group Assignment\\";
        String fileName = "minesweeper_input.txt";
        String fileOutput = "minesweeper_output.txt";
        boolean fileCheck = false;

        //prompts user for file or to type
        System.out.println("Use file? or type?(default to type): ");
        String check = sc.next();
        //if file prompt default or new
        if(check.equalsIgnoreCase("file")) {
            fileCheck = true;
            System.out.println("Default file or new file?: ");
            String newFileName = sc.next();
            //default
            if(newFileName.equalsIgnoreCase("default")) {
                fileCheck = true;
            }
            //new file
            else {
                fileCheck = true;
                System.out.println("Enter file name: ");
                fileName = sc.next();
                System.out.println("Enter file location(or default): ");
                fileLocation  = sc.next();
                if(fileLocation.equalsIgnoreCase("default")) {
                    fileLocation = "C:\\Users\\Guilty\\Documents\\UWT 2018 -" +
                            " present\\UWT 2021 - 2022\\Winter\\TCSS 360\\Group Assignment\\";
                }
            }
        } else {


            System.out.println("Enter x(> 0):  ");
            int x = sc.nextInt();
            System.out.println("Enter y(<= 100): ");
            int y = sc.nextInt();

            //setting up the board
            char[][] boardGame = new char[y][x];
            MineSweeperSystem.setSIDE(y);
            MineSweeperSystem.setDEPTH(x);
            MineSweeperSystem.startGame(boardGame);
            MineSweeperSystem.setMines(boardGame);

            //prints board into terminal
            System.out.println(Arrays.deepToString(boardGame).replace("], ", "\n")
                    .replace("[[", "")
                    .replace("]]", "")
                    .replace("[", "")
                    .replace(",", ""));

            //goes to each cell
            for (int row = 0; row < y; row++) {
                for (int col = 0; col < x; col++) {
                    MineSweeperSystem.countAdjacentMines(col,row,boardGame);
                }
            }
            //prints board endgame board
            System.out.println(Arrays.deepToString(boardGame).replace("], ", "\n")
                    .replace("[[", "")
                    .replace("]]", "")
                    .replace("[", "")
                    .replace(",", ""));
        }


        if(fileCheck) {
            try {
                File input = new File(fileLocation + fileName);
                FileWriter output = new FileWriter(fileLocation + fileOutput);
                Scanner scan = new Scanner(input);
                int count = 0;
                boolean check2 = scan.hasNext();
                while (check2) {
                    scan.reset();
                    //uses int as row and col and set up scanner
                    int x = scan.nextInt();
                    int y = scan.nextInt();
                    if(x != 0 || y != 0) {
                        count++;
                        output.write("Field #" + count + ":");
                        output.write("\n");
                        scan.useDelimiter("");
                        if (x > 0 || y > 0) {
                            //sets the board up in 2d array
                            char[][] board = new char[x][y];
                            for (int row = 0; row < x; row++) {
                                for (int col = 0; col < y; col++) {
                                    boolean skip = true;
                                    while (skip) {
                                        char test = scan.next().charAt(0);
                                        if (test == '.' || test == '*') {
                                            board[row][col] = test;
                                            skip = false;

                                        }
                                    }
                                }
                            }

                            //changes board into endgame board
                            MineSweeperSystem.setSIDE(x);
                            MineSweeperSystem.setDEPTH(y);
                            for (int row = 0; row < x; row++) {
                                for (int col = 0; col < y; col++) {
                                    MineSweeperSystem.countAdjacentMines(col, row, board);
                                    output.write(board[row][col]);
                                }
                                output.write("\n");
                            }
                            output.write("\n");
                        }
                    } else {
                        check2 = false;
                    }
                }
                output.close();

            } catch (Exception e) {
                //if error occurs prints error message
                System.out.println("ERROR: " + e);
            }
        }

    }

}