package MineSweeperSystem;
/**
 * MineSweeperSystem.java
 *
 * Methods to create board for minesweeper.
 *
 * @Author Bryan Lam
 * @version winter 2022
 */
public class MineSweeperSystem {

    private static int SIDE;
    private static int DEPTH;

    /**
     * sets sides
     * @param side side
     */
    public static void setSIDE(int side) {
        MineSweeperSystem.SIDE = side;
    }

    /**
     * sets depth
     * @param depth depth
     */
    public static void setDEPTH(int depth) {
        MineSweeperSystem.DEPTH = depth;
    }

    /**
     * Set up the board without any bombs.
     *
     * @param theBoard board
     */
    public static void startGame(char[][] theBoard) {
        for (int row = 0; row < DEPTH; row++) {
            for (int col = 0; col < SIDE; col++) {
                theBoard[col][row] = '.';
            }
        }
    }

    /**
     *  Set up the mines on the board randomly.
     * @param theBoard board
     */
    public static void setMines(char[][] theBoard) {
        for (int row = 0; row < DEPTH; row++) {
            for (int col = 0; col < SIDE; col++) {
                if (Math.random() < .15) {
                    theBoard[col][row] = '*';
                }
            }
        }
    }

    /**
     * checks that row and col given are within bound of the board.
     * @param theCol col
     * @param theRow row
     * @return boolean
     */
    public static  boolean inBoard(int theCol, int theRow) {
        return (theRow >= 0) && ( theRow < DEPTH) &&
                (theCol >= 0) && ( theCol < SIDE);
    }

    /**
     * checks surrounding cells for mines and keeps a count to set
     * the cell into.
     *
     * @param TheCol col
     * @param theRow row
     * @param theBoard board
     */
    public static void countAdjacentMines(int TheCol, int theRow, char[][] theBoard) {
        int count = 0;
        if(theBoard[theRow][TheCol] != '*') {
            //topleft
            if (inBoard(theRow - 1, TheCol - 1)) {
                if (theBoard[theRow - 1][TheCol - 1] == '*') {
                    count++;
                }
            }
            //topmiddle
            if (inBoard(theRow, TheCol - 1)) {
                if (theBoard[theRow][TheCol - 1] == '*') {
                    count++;
                }
            }
            //topright
            if (inBoard(theRow + 1, TheCol - 1)) {
                if (theBoard[theRow + 1][TheCol - 1] == '*') {
                    count++;
                }
            }
            //leftmidlle
            if (inBoard(theRow - 1, TheCol)) {
                if (theBoard[theRow - 1][TheCol] == '*') {
                    count++;
                }
            }
            //rightmiddle
            if (inBoard(theRow + 1, TheCol)) {
                if (theBoard[theRow + 1][TheCol] == '*') {
                    count++;
                }
            }
            //leftbottom
            if (inBoard(theRow - 1, TheCol + 1)) {
                if (theBoard[theRow - 1][TheCol + 1] == '*') {
                    count++;
                }
            }
            //middlebottom
            if (inBoard(theRow, TheCol + 1)) {
                if (theBoard[theRow][TheCol + 1] == '*') {
                    count++;
                }
            }
            //rightbottom
            if (inBoard(theRow + 1, TheCol + 1)) {
                if (theBoard[theRow + 1][TheCol + 1] == '*') {
                    count++;
                }
            }
            theBoard[theRow][TheCol] = (char) (count+'0');
        }
    }

}
